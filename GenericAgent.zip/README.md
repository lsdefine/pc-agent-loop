# GenericAgent

GenericAgent 是一个**极致简约**的自主 AI Agent 框架。它通过不到 100 行的核心代码和约 200 行的工具实现，构筑了强大的跨环境（浏览器、终端、文件系统）自动化能力。

## 🚀 核心特性

- **极简设计**: 仅由 **7 个基本工具** 和一个高效的 **Agentic Loop** 构成，拒绝过度设计。
- **自主代码执行 (Code Execution)**: 能够根据任务需求自主编写并运行 Python 或 PowerShell 脚本。
- **深度 Web 自动化 (Advanced Web Automation)**: 
    - **语义化扫描**: 自动清洗 HTML 内容。
    - **JS 注入执行**: 在浏览器上下文中执行自定义 JavaScript。
    - **TMWebDriver**: 支持持久化会话。**注意：使用前需在浏览器中安装 Tampermonkey 插件并配置对应脚本。**
- **精准文件编辑 (Smart File Patching)**: 支持通过 `file_patch` 以“补丁”方式精确替换代码块。
- **人机协作模式 (Human-in-the-loop)**: 关键决策时主动请求用户指导。

## 📂 项目结构

- `agent_loop.py`: **核心引擎**，管理 Agent 的思考、行动和观察循环。
- `ga.py`: 定义了 **7 大核心工具** 的具体实现逻辑。
- `agentapp.py`: 基于 Streamlit 的极简 Web 交互界面。
- `sidercall.py`: 轻量级 LLM API 通信层。
- `TMWebDriver.py`: 浏览器自动化驱动（依赖 Tampermonkey 环境）。

## 🛠️ 快速开始

### 1. 环境准备
- 确保已安装 Python 3.8+。
- **重要**：若需使用网页自动化功能，请先在常用浏览器中安装 **Tampermonkey** 插件。

### 2. 安装依赖
缺啥装啥

### 3. 启动应用
直接双击运行 `launch.pyw`（Windows 环境），或在终端执行：
```bash
python launch.pyw
```

## 🧩 7 大核心工具

Agent 仅依靠以下 7 个原子工具组合完成复杂任务：
1. `code_run`: 执行 Python/PowerShell 代码。
2. `web_scan`: 结构化扫描网页内容。
3. `web_execute_js`: 网页 JS 脚本注入。
4. `file_read`: 精确读取本地文件。
5. `file_write`: 写入或追加文件内容。
6. `file_patch`: 基于块匹配的源码修改。
7. `ask_user`: 与人类实时交互。

## 🛡️ 开源协议
本项目采用 [MIT License](LICENSE) 开源。

---
**警告**: 本 Agent 具备执行本地代码的能力，请在受信任的环境中运行。